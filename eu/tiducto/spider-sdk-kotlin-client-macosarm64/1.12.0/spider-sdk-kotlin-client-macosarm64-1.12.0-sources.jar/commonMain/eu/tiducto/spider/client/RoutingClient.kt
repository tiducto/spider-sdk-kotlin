package eu.tiducto.spider.client

import eu.tiducto.spider.client.util.decodePolyline
import eu.tiducto.spider.contract.routing.AccessibilityPreferencesInput
import eu.tiducto.spider.contract.routing.AlightPreferencesInput
import eu.tiducto.spider.contract.routing.BoardPreferencesInput
import eu.tiducto.spider.contract.routing.DeparturesRequest
import eu.tiducto.spider.contract.routing.DeparturesResponse
import eu.tiducto.spider.contract.routing.EstimatedDelaysResponse
import eu.tiducto.spider.contract.routing.Itinerary as WireItinerary
import eu.tiducto.spider.contract.routing.Leg as WireLeg
import eu.tiducto.spider.contract.routing.ParentStation as WireParentStation
import eu.tiducto.spider.contract.routing.PickupDropoffType as WirePickupDropoffType
import eu.tiducto.spider.contract.routing.PlanCoordinateInput
import eu.tiducto.spider.contract.routing.PlanDateTimeInput
import eu.tiducto.spider.contract.routing.PlanLabeledLocationInput
import eu.tiducto.spider.contract.routing.PlanLocationInput
import eu.tiducto.spider.contract.routing.PlanModesInput
import eu.tiducto.spider.contract.routing.PlanPassThroughViaLocationInput
import eu.tiducto.spider.contract.routing.PlanPreferencesInput
import eu.tiducto.spider.contract.routing.PlanStopLocationInput
import eu.tiducto.spider.contract.routing.PlanStreamChunkEvent
import eu.tiducto.spider.contract.routing.PlanStreamPageInfoEvent
import eu.tiducto.spider.contract.routing.PlanStreamRequest
import eu.tiducto.spider.contract.routing.PlanStreetPreferencesInput
import eu.tiducto.spider.contract.routing.PlanTransitModePreferenceInput
import eu.tiducto.spider.contract.routing.PlanTransitModesInput
import eu.tiducto.spider.contract.routing.PlanTripRequest
import eu.tiducto.spider.contract.routing.PlanTripResponse
import eu.tiducto.spider.contract.routing.PlanViaLocationInput
import eu.tiducto.spider.contract.routing.PlanVisitViaLocationInput
import eu.tiducto.spider.contract.routing.Reliability as WireReliability
import eu.tiducto.spider.contract.routing.RoutingError as WireRoutingError
import eu.tiducto.spider.contract.routing.TransferPreferencesInput
import eu.tiducto.spider.contract.routing.TransitFilterInput
import eu.tiducto.spider.contract.routing.TransitFilterSelectInput
import eu.tiducto.spider.contract.routing.TransitMode as WireTransitMode
import eu.tiducto.spider.contract.routing.TransitModeCostInput
import eu.tiducto.spider.contract.routing.TransitModePreferenceCostInput
import eu.tiducto.spider.contract.routing.TransitPreferencesInput
import eu.tiducto.spider.contract.routing.TripRequest
import eu.tiducto.spider.contract.routing.TripResponse
import eu.tiducto.spider.contract.routing.TripVehicle as WireTripVehicle
import eu.tiducto.spider.contract.routing.WalkPreferencesInput
import eu.tiducto.spider.contract.routing.WheelchairPreferencesInput
import io.ktor.client.HttpClient
import io.ktor.client.plugins.sse.SSE
import io.ktor.client.plugins.sse.SSEClientException
import io.ktor.client.plugins.sse.sse
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.accept
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.request.url
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import kotlin.time.Duration
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Instant
import kotlin.time.measureTime
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.toImmutableList
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.io.IOException
import kotlinx.serialization.SerializationException
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

// gtfsIds are opaque and feed-prefixed ("1:U…"); the SDK never re-prefixes them — a stop id from search
// feeds straight into plan()/departures()/trip() (re-prefixing is what once 404'd).
internal class RoutingClient(
    private val baseUrl: String,
    private val apiKey: String,
    retry: RetryConfig? = null,
    private val log: SpiderLog,
) {
    // explicitNulls=false so an omitted optional reads as "unset" upstream. Unknown enum values decode to
    // UNKNOWN via the generated enums' serializers (coercion doesn't — it throws).
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    }

    private val http = HttpClient {
        install(SSE)
        installApiKey(apiKey)
        installAutoRetry(retry)
        installSpiderLogging(log, "SpiderRouting")
    }

    suspend fun planConnection(
        request: PlanRequest,
        before: String? = null,
        after: String? = null,
    ): Route {
        val plan: PlanTripResponse = postJson(PLAN, request.toPlanTripRequest(before, after))

        return Route(
            request = request,
            edges = plan.itineraries.map { RouteEdge(cursor = NO_CURSOR, itinerary = it.toDomainItinerary()) }
                .toImmutableList(),
            pageInfo = RoutePageInfo(
                startCursor = plan.pageInfo.startCursor,
                endCursor = plan.pageInfo.endCursor,
                hasNextPage = plan.pageInfo.hasNextPage,
                hasPreviousPage = plan.pageInfo.hasPreviousPage,
                searchWindowUsed = plan.pageInfo.searchWindowUsed,
            ),
            routingErrors = plan.routingErrors.map { it.toDomainRoutingError() }.toImmutableList(),
            searchDateTime = plan.searchDateTime,
        )
    }

    fun planConnectionStream(
        request: PlanRequest,
        targetResults: Int,
        maxWindow: Duration,
        before: String? = null,
        after: String? = null,
    ): Flow<PlanStreamEvent> = flow {
        var ended = false
        try {
            val payload = json.encodeToString(request.toPlanStreamRequest(targetResults, maxWindow, before, after))
            http.sse(
                request = {
                    method = HttpMethod.Post
                    url("$baseUrl/$ROUTING/$PLAN_STREAM")
                    contentType(ContentType.Application.Json)
                    accept(ContentType.Text.EventStream)
                    spiderHeaders()
                    setBody(payload)
                },
            ) {
                incoming.collect { record ->
                    // Drained past Done: the gateway meters the stream off its closing `done`.
                    if (ended) return@collect
                    val event = parsePlanStreamRecord(record.event ?: SSE_DEFAULT_EVENT, record.data.orEmpty(), json)
                        ?: return@collect
                    ended = event !is PlanStreamEvent.Result
                    emit(event)
                }
            }
            if (!ended) {
                val cut = IOException("routing $PLAN_STREAM ended before pageInfo")
                emit(PlanStreamEvent.Failure(cut.toSpiderError()))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: SSEClientException) {
            if (!ended) emit(PlanStreamEvent.Failure(e.toStreamFailure()))
        } catch (e: Exception) {
            if (!ended) emit(PlanStreamEvent.Failure(e.toSpiderError()))
        }
    }.flowOn(Dispatchers.Default)

    suspend fun stopDepartures(
        id: String,
        numberOfDepartures: Int,
        startTime: Instant?,
        timeRange: Duration,
        reliability: Reliability?,
        excludedModes: Set<TransitMode>?,
    ): StopDepartures {
        val timeRangeSeconds = timeRange.inWholeSeconds
        requireInRange("timeRange", timeRangeSeconds in 1..MAX_TIME_RANGE_SECONDS)
        val body = DeparturesRequest(
            id = id,
            numberOfDepartures = numberOfDepartures,
            timeRange = timeRangeSeconds.toInt(),
            startTime = startTime?.epochSeconds,
            reliability = reliability?.toWire(),
            excludeModes = excludedModes.toWireTransitModes(),
        )
        val stop = postJson<DeparturesRequest, DeparturesResponse>(DEPARTURES, body).stop
            ?: throw SpiderTransportException.NoData("routing returned no stop or station for id=$id")

        val departures = stop.stoptimesWithoutPatterns.map { st ->
            val route = st.trip.route
            Departure(
                scheduledTime = Instant.fromEpochSeconds(st.serviceDay + st.scheduledDeparture),
                realtimeTime = Instant.fromEpochSeconds(st.serviceDay + st.realtimeDeparture),
                isRealtime = st.realtime,
                realtimeState = realtimeStateFromWire(st.realtimeState.value),
                headsign = st.headsign,
                tripGtfsId = st.trip.gtfsId,
                serviceDate = st.serviceDate,
                routeShortName = route.shortName,
                routeLongName = route.longName,
                mode = modeFromWire(route.mode.value),
                routeGtfsId = route.gtfsId,
                routeColor = route.color,
                routeTextColor = route.textColor,
                stopGtfsId = st.stop.gtfsId,
                platformCode = st.stop.platformCode,
                wheelchairAccessible = wheelchairFromWire(st.trip.wheelchairAccessible.value),
                typicalDelay = st.typicalDelay?.seconds,
                stopPosition = st.stopPosition,
                pickupType = pickupDropoffFromWire(st.pickupType),
                dropoffType = pickupDropoffFromWire(st.dropoffType),
                vehicle = st.vehicle?.toDomain(),
            )
        }.toImmutableList()

        return StopDepartures(
            gtfsId = stop.gtfsId,
            name = stop.name,
            wheelchairBoarding = stop.wheelchairBoarding?.let { wheelchairFromWire(it.value) },
            parentStation = stop.parentStation?.toDomain(),
            departures = departures,
        )
    }

    /** [serviceDate] is the GTFS service date, formatted "YYYY-MM-DD". */
    suspend fun trip(tripId: String, serviceDate: String, reliability: Reliability?, startTime: String? = null): TripDetails {
        requireServiceDate(serviceDate)
        val run = requireStartTime(startTime)
        val body = TripRequest(
            id = tripId,
            serviceDate = serviceDate,
            startTime = run,
            reliability = reliability?.toWire(),
        )
        val trip = postJson<TripRequest, TripResponse>(TRIP, body).trip
            ?: throw SpiderTransportException.NoData("routing returned no trip for id=$tripId")

        val stops = trip.stoptimesForDate.map { st ->
            val s = st.stop
            fun at(offset: Int): Instant = Instant.fromEpochSeconds(st.serviceDay + offset)
            TripStop(
                gtfsId = s.gtfsId,
                name = s.name,
                lat = s.lat,
                lon = s.lon,
                scheduledArrival = at(st.scheduledArrival),
                scheduledDeparture = at(st.scheduledDeparture),
                realtimeArrival = at(st.realtimeArrival),
                realtimeDeparture = at(st.realtimeDeparture),
                isRealtime = st.realtime,
                wheelchairBoarding = wheelchairFromWire(s.wheelchairBoarding.value),
                platformCode = s.platformCode,
                zoneId = s.zoneId,
                typicalDelay = st.typicalDelay?.seconds,
                stopPosition = st.stopPosition,
                geometryIndex = st.geometryIndex,
                pickupType = st.pickupType?.let(::pickupDropoffFromWire),
                dropoffType = st.dropoffType?.let(::pickupDropoffFromWire),
                parentStation = s.parentStation?.toDomain(),
            )
        }

        return TripDetails(
            gtfsId = trip.gtfsId,
            serviceDate = serviceDate,
            routeShortName = trip.route.shortName,
            routeLongName = trip.route.longName,
            mode = modeFromWire(trip.route.mode.value),
            headsign = trip.tripHeadsign,
            directionId = trip.directionId,
            bikesAllowed = bikesAllowedFromWire(trip.bikesAllowed.value),
            stops = stops.toImmutableList(),
            geometry = trip.tripGeometry?.points?.let { decodePolyline(it).toImmutableList() }
                ?: persistentListOf(),
            routeGtfsId = trip.route.gtfsId,
            routeColor = trip.route.color,
            routeTextColor = trip.route.textColor,
            wheelchairAccessible = wheelchairFromWire(trip.wheelchairAccessible.value),
            vehicle = trip.vehicle?.toDomain(),
        )
    }

    // Null is the API's answer for an unknown trip, a stop position off the trip, or no history. Entries are
    // matched by level; a level that is missing or repeated is a malformed body.
    suspend fun estimatedDelays(
        tripId: String,
        serviceDate: String,
        stopPosition: Int,
        startTime: String? = null,
    ): EstimatedDelays? {
        requireServiceDate(serviceDate)
        val run = requireStartTime(startTime)
        val entries = getJson<EstimatedDelaysResponse>(ESTIMATED_DELAYS) {
            parameter("tripId", tripId)
            parameter("serviceDate", serviceDate)
            parameter("stopPosition", stopPosition)
            parameter("startTime", run)
        }.estimatedDelays ?: return null

        fun at(level: WireReliability): Duration =
            entries.singleOrNull { it.reliability == level }?.delay?.seconds
                ?: throw SerializationException("routing $ESTIMATED_DELAYS has no single ${level.value} entry")
        return EstimatedDelays(
            standard = at(WireReliability.STANDARD),
            safe = at(WireReliability.SAFE),
            verySafe = at(WireReliability.VERY_SAFE),
        )
    }

    // Best-effort connection pre-warm. One bare GET to {baseUrl}/ping through *this* surface's HttpClient, so
    // the TLS connection it opens lands in the pool planConnection reuses. The client apikey rides on it via
    // the client's DefaultRequest (shared setup), not a per-call header; no contract/sdk headers (/ping isn't
    // contract-gated) — a keyed gateway requires the apikey, a keyless one ignores it. Never throws: any
    // transport error or non-2xx (incl. 401/403/404) still warms the connection, so we swallow it and return
    // the elapsed.
    internal suspend fun warmup(): Duration = measureTime {
        runCatching { http.get(baseUrl.trimEnd('/') + "/ping") }
            .onSuccess { log.d(tag = "SpiderRouting") { "warmup GET /ping → ${it.status.value}" } }
            .onFailure { e ->
                // runCatching also catches CancellationException; rethrow it so a cancelled warmup
                // propagates instead of being swallowed as "connection still warmed".
                if (e is CancellationException) throw e
                log.d(tag = "SpiderRouting") { "warmup GET /ping failed (connection still warmed): ${e.message}" }
            }
    }

    private suspend inline fun <reified B, reified R> postJson(op: String, body: B): R = decode(
        op,
        http.post {
            url("$baseUrl/$ROUTING/$op")
            contentType(ContentType.Application.Json)
            spiderHeaders()
            setBody(json.encodeToString(body))
        },
    )

    private suspend inline fun <reified R> getJson(op: String, crossinline query: HttpRequestBuilder.() -> Unit): R =
        decode(
            op,
            http.get {
                url("$baseUrl/$ROUTING/$op")
                query()
                spiderHeaders()
            },
        )

    private suspend inline fun <reified R> decode(op: String, response: HttpResponse): R {
        val text = response.bodyAsText()
        if (!response.status.isSuccess()) throw routingHttpFailure(op, response.status.value, text)
        return json.decodeFromString<R>(text)
    }
}

private const val ROUTING = "routing/v1"
private const val PLAN = "plan"
private const val PLAN_STREAM = "plan-stream"
private const val DEPARTURES = "departures"
private const val TRIP = "trip"
private const val ESTIMATED_DELAYS = "estimated-delays"
private const val NO_CURSOR = "NoCursor"

internal fun transitModeFromWire(raw: String?): TransitMode? = when (raw) {
    null -> null
    "WALK" -> TransitMode.WALK
    "BUS" -> TransitMode.BUS
    "COACH" -> TransitMode.COACH
    "TROLLEYBUS" -> TransitMode.TROLLEYBUS
    "CARPOOL" -> TransitMode.CARPOOL
    "TRAM" -> TransitMode.TRAM
    "RAIL" -> TransitMode.RAIL
    "SUBWAY" -> TransitMode.SUBWAY
    "MONORAIL" -> TransitMode.MONORAIL
    "FERRY" -> TransitMode.FERRY
    "AIRPLANE" -> TransitMode.AIRPLANE
    "TAXI" -> TransitMode.TAXI
    "CABLE_CAR" -> TransitMode.CABLE_CAR
    "GONDOLA" -> TransitMode.GONDOLA
    "FUNICULAR" -> TransitMode.FUNICULAR
    "SNOW_AND_ICE" -> TransitMode.SNOW_AND_ICE
    // TRANSIT + any value the upstream engine adds later.
    else -> TransitMode.UNKNOWN
}

private fun modeFromWire(raw: String): TransitMode = transitModeFromWire(raw) ?: TransitMode.UNKNOWN

private fun realtimeStateFromWire(raw: String): RealtimeState =
    RealtimeState.entries.firstOrNull { it.name == raw } ?: RealtimeState.UNKNOWN

private fun pickupDropoffFromWire(raw: WirePickupDropoffType): PickupDropoffType =
    PickupDropoffType.entries.firstOrNull { it.name == raw.value } ?: PickupDropoffType.UNKNOWN

private fun WireRoutingError.toDomainRoutingError(): RoutingError = RoutingError(
    code = RoutingErrorCode.entries.firstOrNull { it.name == code.value } ?: RoutingErrorCode.UNKNOWN,
    description = description,
    inputField = inputField?.let { field -> InputField.entries.firstOrNull { it.name == field.value } ?: InputField.UNKNOWN },
)

private fun wheelchairFromWire(raw: String?): WheelchairBoarding? = when (raw) {
    null, "NO_INFORMATION" -> null
    "POSSIBLE" -> WheelchairBoarding.POSSIBLE
    "NOT_POSSIBLE" -> WheelchairBoarding.NOT_POSSIBLE
    else -> WheelchairBoarding.UNKNOWN
}

private fun bikesAllowedFromWire(raw: String?): BikesAllowed? = when (raw) {
    null, "NO_INFORMATION" -> null
    "ALLOWED" -> BikesAllowed.ALLOWED
    "NOT_ALLOWED" -> BikesAllowed.NOT_ALLOWED
    else -> BikesAllowed.UNKNOWN
}

private fun durationFromWire(raw: String): Duration? {
    if (raw.isBlank()) return null
    return runCatching { Duration.parseIsoString(raw) }.getOrNull()
        ?: raw.toLongOrNull()?.seconds
}

private fun WireItinerary.toDomainItinerary(): Itinerary = Itinerary(
    start = start,
    end = end,
    durationSeconds = duration,
    waitingTimeSeconds = waitingTime,
    numberOfTransfers = numberOfTransfers,
    legs = legs.map { it.toDomainLeg() }.toImmutableList(),
)

private fun WireLeg.toDomainLeg(): Leg = Leg(
    mode = modeFromWire(mode.value),
    startScheduled = start.scheduledTime,
    endScheduled = end.scheduledTime,
    startEstimated = start.estimated?.time,
    endEstimated = end.estimated?.time,
    startDelay = start.estimated?.delay?.let(::durationFromWire),
    endDelay = end.estimated?.delay?.let(::durationFromWire),
    isRealtime = realTime,
    realtimeState = realtimeStateFromWire(realtimeState.value),
    serviceDate = serviceDate,
    fromName = from.name,
    toName = to.name,
    fromGtfsId = from.stop?.gtfsId,
    toGtfsId = to.stop?.gtfsId,
    routeShortName = route?.shortName,
    routeLongName = route?.longName,
    headsign = headsign,
    distanceMeters = distance,
    durationSeconds = duration,
    tripGtfsId = trip?.gtfsId,
    bikesAllowed = trip?.let { bikesAllowedFromWire(it.bikesAllowed.value) },
    fromWheelchair = from.stop?.let { wheelchairFromWire(it.wheelchairBoarding.value) },
    toWheelchair = to.stop?.let { wheelchairFromWire(it.wheelchairBoarding.value) },
    geometry = decodePolyline(legGeometry.points).toImmutableList(),
    routeGtfsId = route?.gtfsId,
    routeColor = route?.color,
    routeTextColor = route?.textColor,
    fromPlatformCode = from.stop?.platformCode,
    toPlatformCode = to.stop?.platformCode,
    fromZoneId = from.stop?.zoneId,
    toZoneId = to.stop?.zoneId,
    typicalArrivalDelay = typicalArrivalDelay?.seconds,
    interlineWithPreviousLeg = interlineWithPreviousLeg,
    fromStopPosition = from.stopPosition,
    toStopPosition = to.stopPosition,
    pickupType = pickupDropoffFromWire(pickupType),
    dropoffType = pickupDropoffFromWire(dropoffType),
    vehicle = vehicle?.toDomain(),
    fromParentStation = from.stop?.parentStation?.toDomain(),
    toParentStation = to.stop?.parentStation?.toDomain(),
)

private fun WireParentStation.toDomain(): ParentStation = ParentStation(gtfsId = gtfsId, name = name)

private fun WireTripVehicle.toDomain(): TripVehicle = TripVehicle(
    id = id,
    label = label,
    wheelchairAccessible = wheelchairFromWire(wheelchairAccessible.value),
    airConditioning = airConditioning,
    wifi = wifi,
    cardPayment = cardPayment,
)

private const val SSE_DEFAULT_EVENT = "message"

internal fun parsePlanStreamRecord(event: String, data: String, json: Json): PlanStreamEvent? {
    if (data.isBlank()) return null
    return when (event) {
        "chunk" -> runCatching {
            val chunk = json.decodeFromString<PlanStreamChunkEvent>(data)
            PlanStreamEvent.Result(chunk.results.map { it.toDomainItinerary() }.toImmutableList())
        }.getOrElse { PlanStreamEvent.Failure(it.toSpiderError()) }

        "pageInfo" -> runCatching {
            val page = json.decodeFromString<PlanStreamPageInfoEvent>(data)
            PlanStreamEvent.Done(
                RoutePageInfo(
                    startCursor = page.startCursor,
                    endCursor = page.endCursor,
                    hasNextPage = page.hasNextPage,
                    hasPreviousPage = page.hasPreviousPage,
                    searchWindowUsed = page.searchWindowUsed,
                ),
                routingErrors = page.routingErrors.map { it.toDomainRoutingError() }.toImmutableList(),
            )
        }.getOrElse { PlanStreamEvent.Failure(it.toSpiderError()) }

        else -> null
    }
}

// Raised for a non-2xx answer and for a failure after a 2xx head.
private suspend fun SSEClientException.toStreamFailure(): SpiderError {
    val response = response?.takeUnless { it.status.isSuccess() } ?: return (cause ?: this).toSpiderError()
    val body = runCatching { response.bodyAsText() }
        .onFailure { if (it is CancellationException) throw it }
        .getOrNull()?.takeIf { it.isNotBlank() }
        ?: (message ?: "stream failed")
    return routingHttpFailure(PLAN_STREAM, response.status.value, body).toSpiderError()
}

internal fun routingHttpFailure(path: String, status: Int, body: String): SpiderTransportException {
    val envelope = parseErrorEnvelope(body)
    envelope.planLimitCode?.let { return planLimitFailure("routing $path", status, it, envelope.message) }
    val detail = envelope.message ?: body.take(300).trim()
    return SpiderTransportException.Http(status, "routing $path → $status: $detail", envelope.code, detail, envelope.field)
}

internal fun PlanRequest.toPlanTripRequest(before: String?, after: String?): PlanTripRequest {
    requireValidVia()
    return PlanTripRequest(
        dateTime = toDateTimeInput(),
        origin = origin.toInput(),
        destination = destination.toInput(),
        searchWindow = searchWindow.toIsoString(),
        via = toViaInputs(),
        modes = toModesInput(),
        preferences = toPreferencesInput(),
        first = numberOfItineraries.takeIf { before == null },
        last = numberOfItineraries.takeIf { before != null },
        before = before,
        after = after,
        reliability = reliability?.toWire(),
    )
}

internal fun PlanRequest.toPlanStreamRequest(
    targetResults: Int,
    maxWindow: Duration,
    before: String?,
    after: String?,
): PlanStreamRequest {
    requireInRange("maxWindow", maxWindow >= MIN_STREAM_WINDOW)
    requireValidVia()
    return PlanStreamRequest(
        dateTime = toDateTimeInput(),
        origin = origin.toInput(),
        destination = destination.toInput(),
        targetResults = targetResults,
        maxWindow = maxWindow.toIsoString(),
        via = toViaInputs(),
        modes = toModesInput(),
        preferences = toPreferencesInput(),
        before = before,
        after = after,
        reliability = reliability?.toWire(),
    )
}

// The fixed platform limits on each via location. How many via locations are allowed is an environment
// setting, which the API checks.
internal fun PlanRequest.requireValidVia() = via.forEach { location ->
    when (location) {
        is ViaLocation.PassThrough -> requireInRange("via", location.stopIds.size in 1..MAX_VIA_STOP_IDS)
        is ViaLocation.Visit ->
            requireInRange("via.visit.minimumWaitTime", location.minimumWaitTime in Duration.ZERO..MAX_VIA_WAIT)
    }
}

private val MIN_STREAM_WINDOW = 2.hours
private val MAX_VIA_WAIT = 1.hours
private const val MAX_VIA_STOP_IDS = 10
private const val MAX_TIME_RANGE_SECONDS = 86_400L

// Curated PlanRequest → OTP's nested modes/preferences inputs. Only the fields the SDK exposes are set;
// everything else stays null so the environment's routing defaults apply.
internal fun PlanRequest.toModesInput(): PlanModesInput? {
    // WALK/UNKNOWN have no transit-mode wire value (WALK is a street mode) and drop out; empty ⇒ no filter.
    val allowed = allowedTransitModes.toWireTransitModes()
    val exclude = excludedTransitModes.toWireTransitModes()
    // The API refuses both lists in one request; refuse it here, before the request, with the API's own field.
    if (allowed != null && exclude != null) throw SpiderTransportException.BadRequest(MODES_TRANSIT, "$MODES_TRANSIT is invalid")
    val reluctances = preferences?.modeReluctance.toWireReluctances(if (allowed == null) COSTS_RELUCTANCE else ALLOWED_RELUCTANCE)
    // An allow-list carries its modes' reluctances itself, and the API refuses costs beside one.
    val transit = allowed?.map { mode ->
        PlanTransitModePreferenceInput(mode = mode, cost = reluctances[mode]?.let(::TransitModePreferenceCostInput))
    }
    val costs = if (allowed == null) reluctances.map { (mode, reluctance) -> TransitModeCostInput(mode, reluctance) }.takeIf { it.isNotEmpty() } else null
    val transitModes = if (transit == null && exclude == null && costs == null) {
        null
    } else {
        PlanTransitModesInput(transit = transit, exclude = exclude, costs = costs)
    }
    if (transitModes == null && !transitOnly) return null
    return PlanModesInput(transitOnly = transitOnly.takeIf { it }, transit = transitModes)
}

// In TransitMode declaration order, so the body is deterministic; WALK/UNKNOWN drop out after the range check.
private fun Map<TransitMode, Double>?.toWireReluctances(field: String): Map<WireTransitMode, Double> {
    if (this == null) return emptyMap()
    values.forEach { requireInRange(field, it in MIN_MULTIPLIER..MAX_MULTIPLIER) }
    return TransitMode.entries.mapNotNull { mode ->
        val reluctance = this[mode] ?: return@mapNotNull null
        mode.toWireTransitMode()?.let { it to reluctance }
    }.toMap()
}

private const val MODES_TRANSIT = "modes.transit"
private const val COSTS_RELUCTANCE = "$MODES_TRANSIT.costs.reluctance"
private const val ALLOWED_RELUCTANCE = "$MODES_TRANSIT.transit.cost.reluctance"

// A filter's wire modes: WALK/UNKNOWN drop out, and null or empty (also once they have) is no filter.
private fun Set<TransitMode>?.toWireTransitModes(): List<WireTransitMode>? =
    this?.mapNotNull { it.toWireTransitMode() }?.takeIf { it.isNotEmpty() }

internal fun PlanRequest.toPreferencesInput(): PlanPreferencesInput? {
    preferences?.requireInRange()
    // The router indexes legs with leg 0 = the initial access (walk, or nothing), so its wire
    // `maximumTransfers` counts boardings = transfers + 1 (wire 0 = walk-only, not exposed here).
    // `maxTransfers` is a transfer count, so map it to boardings: 0 transfers = 1 boarding (direct).
    val transfer = TransferPreferencesInput(
        cost = preferences?.transferCost,
        slack = preferences?.transferSlack?.toIsoString(),
        maximumTransfers = maxTransfers?.let { it + 1 },
    ).takeUnless { it == TransferPreferencesInput() }
    val board = BoardPreferencesInput(
        waitReluctance = preferences?.waitReluctance,
        slack = preferences?.boardSlack?.toIsoString(),
    ).takeUnless { it == BoardPreferencesInput() }
    val alight = preferences?.alightSlack?.let { AlightPreferencesInput(slack = it.toIsoString()) }
    val filters = preferences?.toFilterInputs()
    val transit = TransitPreferencesInput(transfer = transfer, board = board, alight = alight, filters = filters)
        .takeUnless { it == TransitPreferencesInput() }
    val walk = WalkPreferencesInput(
        speed = preferences?.walkSpeed,
        reluctance = preferences?.walkReluctance,
        boardCost = preferences?.boardCost,
    ).takeUnless { it == WalkPreferencesInput() }
    val accessibility = if (wheelchairAccessible) {
        AccessibilityPreferencesInput(wheelchair = WheelchairPreferencesInput(enabled = true))
    } else {
        null
    }
    val street = walk?.let { PlanStreetPreferencesInput(walk = it) }
    return PlanPreferencesInput(street = street, transit = transit, accessibility = accessibility)
        .takeUnless { it == PlanPreferencesInput() }
}

// One filter excluding the routes and the agencies; an empty selector is no exclusion, and the API refuses one.
private fun RoutePreferences.toFilterInputs(): List<TransitFilterInput>? {
    val selectors = listOfNotNull(
        excludedRoutes?.takeIf { it.isNotEmpty() }?.let { TransitFilterSelectInput(routes = it.toList()) },
        excludedAgencies?.takeIf { it.isNotEmpty() }?.let { TransitFilterSelectInput(agencies = it.toList()) },
    )
    return if (selectors.isEmpty()) null else listOf(TransitFilterInput(exclude = selectors))
}

// The contract's fixed bounds, refused before the request with the API's own field, as the API answers them.
private fun RoutePreferences.requireInRange() {
    walkSpeed?.let { requireInRange("$WALK.speed", it.isFinite() && it >= MIN_MULTIPLIER) }
    walkReluctance?.let { requireInRange("$WALK.reluctance", it in MIN_MULTIPLIER..MAX_MULTIPLIER) }
    boardCost?.let { requireInRange("$WALK.boardCost", it in 0..MAX_COST) }
    transferCost?.let { requireInRange("$TRANSIT.transfer.cost", it in 0..MAX_COST) }
    transferSlack?.let { requireInRange("$TRANSIT.transfer.slack", it in Duration.ZERO..MAX_SLACK) }
    waitReluctance?.let { requireInRange("$TRANSIT.board.waitReluctance", it in MIN_MULTIPLIER..MAX_MULTIPLIER) }
    boardSlack?.let { requireInRange("$TRANSIT.board.slack", it in Duration.ZERO..MAX_SLACK) }
    alightSlack?.let { requireInRange("$TRANSIT.alight.slack", it in Duration.ZERO..MAX_SLACK) }
}

private const val WALK = "preferences.street.walk"
private const val TRANSIT = "preferences.transit"
private const val MIN_MULTIPLIER = 0.1
private const val MAX_MULTIPLIER = 100_000.0
private const val MAX_COST = 1_000_000
private val MAX_SLACK = 1.hours

private fun Reliability.toWire(): WireReliability = when (this) {
    Reliability.STANDARD -> WireReliability.STANDARD
    Reliability.SAFE -> WireReliability.SAFE
    Reliability.VERY_SAFE -> WireReliability.VERY_SAFE
}

private fun TransitMode.toWireTransitMode(): WireTransitMode? =
    WireTransitMode.entries.firstOrNull { it.name == name && it != WireTransitMode.UNKNOWN }

private fun PlanRequest.toDateTimeInput(): PlanDateTimeInput = when (val time = time) {
    is RouteTime.DepartAt -> PlanDateTimeInput(earliestDeparture = time.time.toString())
    is RouteTime.ArriveBy -> PlanDateTimeInput(latestArrival = time.time.toString())
}

private fun PlanRequest.toViaInputs(): List<PlanViaLocationInput>? = via.takeIf { it.isNotEmpty() }?.map { it.toInput() }

private fun Location.toInput(): PlanLabeledLocationInput = PlanLabeledLocationInput(
    location = when (this) {
        is Location.Stop -> PlanLocationInput(stopLocation = PlanStopLocationInput(stopLocationId = id))
        is Location.Coordinate -> PlanLocationInput(coordinate = PlanCoordinateInput(latitude = latitude, longitude = longitude))
    },
)

private fun ViaLocation.toInput(): PlanViaLocationInput = when (this) {
    is ViaLocation.PassThrough -> PlanViaLocationInput(passThrough = PlanPassThroughViaLocationInput(stopLocationIds = stopIds))
    is ViaLocation.Visit -> when (val loc = location) {
        is Location.Stop -> PlanViaLocationInput(
            visit = PlanVisitViaLocationInput(
                stopLocationIds = listOf(loc.id),
                minimumWaitTime = minimumWaitTime.takeIf { it > Duration.ZERO }?.toIsoString(),
            ),
        )
        is Location.Coordinate -> throw SpiderTransportException.BadRequest("via", "via is invalid")
    }
}
