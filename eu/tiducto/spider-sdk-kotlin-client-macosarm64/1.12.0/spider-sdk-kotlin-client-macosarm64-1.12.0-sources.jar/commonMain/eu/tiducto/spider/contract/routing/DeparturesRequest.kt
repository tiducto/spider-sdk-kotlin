package eu.tiducto.spider.contract.routing

import kotlinx.serialization.Serializable

/**
 * POST body for `/routing/v1/departures`. A key not listed here is a 400 `<key> is not allowed`, whatever its value, null included. Every bound is rejected, never clamped. `null` on an optional member means absent, and on a required member is a 400 `<path> is required`.
 */
@Serializable
internal data class DeparturesRequest(
    /** Feed-prefixed id (`<feedId>:<id>`) of a stop, for that stop's departures, or of a station, for the departures of all its stops. A bare or foreign-prefixed id resolves to nothing, and `stop` is null. */
    val id: String,
    /** Most departures returned: 1 up to the environment's limit; rejected, never clamped. */
    val numberOfDepartures: Int,
    /** Seconds after `startTime` the departures cover: 1 to 86400 (24 hours); rejected, never clamped. */
    val timeRange: Int,
    /** Unix seconds the departures start at, from 0 to 4102444799 (2099-12-31T23:59:59Z). Absent or 0 means now. */
    val startTime: Long? = null,
    /** The level `typicalDelay` is given at; the times do not depend on it. Omitted or null, `typicalDelay` is null. A value outside `Reliability` is a 400 `reliability is invalid`. */
    val reliability: Reliability? = null,
    /** Modes left out of the departures: a departure whose route's `mode` is listed gives no row. They are left out before `numberOfDepartures` counts, so the response holds up to `numberOfDepartures` rows of the other modes within `timeRange`. Absent or empty leaves out nothing. A value outside `TransitMode` is a 400 `excludeModes is invalid`. */
    val excludeModes: List<TransitMode>? = null
)
