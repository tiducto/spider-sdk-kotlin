package eu.tiducto.spider.client

import kotlin.time.Clock
import kotlin.time.Duration
import kotlin.time.Duration.Companion.hours
import kotlin.time.Instant
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable

class SpiderRouting(
    private val baseUrl: String,
    apiKey: String,
    retry: RetryConfig? = null,
    logging: LoggingConfig = LoggingConfig(),
) {
    private val log = logging.buildLog()
    private val routing = RoutingClient(baseUrl, apiKey, retry, log)

    /**
     * One page of itineraries. [allowedTransitModes] restricts routing to those modes, and [excludedTransitModes]
     * keeps it off those modes while every other mode, including one the API adds later, stays usable. Use one of
     * them: both non-empty returns [SpiderError.BadRequest] for `modes.transit` without a request. Null or empty
     * means no filter, and [TransitMode.WALK] and [TransitMode.UNKNOWN] are ignored in either. [planNext] and
     * [planPrevious] resend the same filters.
     */
    suspend fun plan(
        origin: Location,
        destination: Location,
        time: RouteTime = RouteTime.DepartAt(Clock.System.now()),
        via: List<ViaLocation> = emptyList(),
        allowedTransitModes: Set<TransitMode>? = null,
        maxTransfers: Int? = null,
        searchWindow: Duration = 1.hours,
        wheelchairAccessible: Boolean = false,
        reliability: Reliability? = null,
        excludedTransitModes: Set<TransitMode>? = null,
    ): SpiderResult<Route> = page(
        PlanRequest(
            origin, destination, time, via,
            allowedTransitModes, maxTransfers, searchWindow, wheelchairAccessible, reliability, excludedTransitModes,
        ),
    )

    /**
     * Plans the next window of itineraries (later departures). Returns null if no next window is available.
     */
    suspend fun planNext(prev: Route): SpiderResult<Route>? =
        if (!prev.pageInfo.hasNextPage) null
        else page(prev.request, after = prev.pageInfo.endCursor)

    /**
     * Plans the previous window of itineraries (earlier departures). Returns null if no previous window is available.
     */
    suspend fun planPrevious(prev: Route): SpiderResult<Route>? =
        if (!prev.pageInfo.hasPreviousPage) null
        else page(prev.request, before = prev.pageInfo.startCursor)

    // Cursor paging only — no page-size count. Each page is one search window, holding at most the
    // environment's result count; `before`/`after` walk the windows.
    private suspend fun page(
        request: PlanRequest,
        before: String? = null,
        after: String? = null,
    ): SpiderResult<Route> = context(log) {
        spiderCall(
            tag = "SpiderRouting",
            message = {
                "plan failed against $baseUrl (origin=${request.origin} destination=${request.destination} before=$before after=$after)"
            },
        ) {
            routing.planConnection(request, before = before, after = after)
        }
    }

    /**
     * Streams itineraries over Server-Sent Events as the router sweeps the search window forward, emitting
     * them as they finalize instead of one batched page. Cold and cancellable: collection starts the request,
     * cancelling it stops the sweep. Each [PlanStreamEvent.Result] carries itineraries with realtime delays
     * already applied to their legs; a terminal [PlanStreamEvent.Done] then carries the continuation cursors
     * and any routing errors (or a terminal [PlanStreamEvent.Failure]).
     *
     * [targetResults] is how many itineraries the sweep aims for, from 1 up to the environment's result
     * count. [maxWindow] is how far the sweep may search, in either direction: at least 2 hours, up to the
     * environment's search-window limit. Both are required. A [maxWindow] under 2 hours ends the stream in a
     * [PlanStreamEvent.Failure] with [SpiderError.BadRequest] before any request; the API rejects values over
     * the environment's limits the same way. [reliability] plans arrivals with typical delays, and
     * [allowedTransitModes] / [excludedTransitModes] filter modes, as in [plan]; a continuation must repeat them.
     *
     * To continue, call [planStreamNext] with `after` = [PlanStreamEvent.Done]'s [RoutePageInfo.endCursor]
     * (or [planStreamPrevious] with `before` = [RoutePageInfo.startCursor] to walk earlier). For a single
     * batched page instead, use [plan].
     */
    fun planStream(
        origin: Location,
        destination: Location,
        time: RouteTime = RouteTime.DepartAt(Clock.System.now()),
        via: List<ViaLocation> = emptyList(),
        allowedTransitModes: Set<TransitMode>? = null,
        maxTransfers: Int? = null,
        wheelchairAccessible: Boolean = false,
        targetResults: Int,
        maxWindow: Duration,
        reliability: Reliability? = null,
        excludedTransitModes: Set<TransitMode>? = null,
    ): Flow<PlanStreamEvent> = stream(
        origin, destination, time, via, allowedTransitModes, maxTransfers,
        wheelchairAccessible, targetResults, maxWindow, reliability, excludedTransitModes, before = null, after = null,
    )

    /**
     * Continues a [planStream] sweep into the next window (later departures) from [after] = a prior
     * [PlanStreamEvent.Done]'s [RoutePageInfo.endCursor] (call this when its [RoutePageInfo.hasNextPage] is
     * set). The inputs are repeated so [targetResults] / [maxWindow] etc. can differ per continuation.
     */
    fun planStreamNext(
        origin: Location,
        destination: Location,
        time: RouteTime = RouteTime.DepartAt(Clock.System.now()),
        via: List<ViaLocation> = emptyList(),
        allowedTransitModes: Set<TransitMode>? = null,
        maxTransfers: Int? = null,
        wheelchairAccessible: Boolean = false,
        targetResults: Int,
        maxWindow: Duration,
        after: String,
        reliability: Reliability? = null,
        excludedTransitModes: Set<TransitMode>? = null,
    ): Flow<PlanStreamEvent> = stream(
        origin, destination, time, via, allowedTransitModes, maxTransfers,
        wheelchairAccessible, targetResults, maxWindow, reliability, excludedTransitModes, before = null, after = after,
    )

    /**
     * Continues a [planStream] sweep into the previous window (earlier departures) from [before] = a prior
     * [PlanStreamEvent.Done]'s [RoutePageInfo.startCursor] (call this when its [RoutePageInfo.hasPreviousPage]
     * is set). The inputs are repeated so [targetResults] / [maxWindow] etc. can differ per continuation.
     */
    fun planStreamPrevious(
        origin: Location,
        destination: Location,
        time: RouteTime = RouteTime.DepartAt(Clock.System.now()),
        via: List<ViaLocation> = emptyList(),
        allowedTransitModes: Set<TransitMode>? = null,
        maxTransfers: Int? = null,
        wheelchairAccessible: Boolean = false,
        targetResults: Int,
        maxWindow: Duration,
        before: String,
        reliability: Reliability? = null,
        excludedTransitModes: Set<TransitMode>? = null,
    ): Flow<PlanStreamEvent> = stream(
        origin, destination, time, via, allowedTransitModes, maxTransfers,
        wheelchairAccessible, targetResults, maxWindow, reliability, excludedTransitModes, before = before, after = null,
    )

    private fun stream(
        origin: Location,
        destination: Location,
        time: RouteTime,
        via: List<ViaLocation>,
        allowedTransitModes: Set<TransitMode>?,
        maxTransfers: Int?,
        wheelchairAccessible: Boolean,
        targetResults: Int,
        maxWindow: Duration,
        reliability: Reliability?,
        excludedTransitModes: Set<TransitMode>?,
        before: String?,
        after: String?,
    ): Flow<PlanStreamEvent> = routing.planConnectionStream(
        request = PlanRequest(
            origin = origin,
            destination = destination,
            time = time,
            via = via,
            allowedTransitModes = allowedTransitModes,
            maxTransfers = maxTransfers,
            wheelchairAccessible = wheelchairAccessible,
            reliability = reliability,
            excludedTransitModes = excludedTransitModes,
        ),
        targetResults = targetResults,
        maxWindow = maxWindow,
        before = before,
        after = after,
    )

    /**
     * The departures board for a stop or station. [numberOfDepartures] (default 30) is capped by the
     * environment. [timeRange] (default 24 hours) is how far ahead of [startTime] (null = now) to look: above
     * zero and at most 24 hours, else [SpiderError.BadRequest] without a request. [reliability] is the level
     * [Departure.typicalDelay] is given at; null leaves it null. The times don't depend on it.
     *
     * [excludedModes] leaves out every departure whose [Departure.mode] is in it. The API drops them before it
     * counts [numberOfDepartures], so the board still holds up to [numberOfDepartures] departures of the other
     * modes, and so does each later board paged by [startTime]. Null or empty leaves out nothing; [TransitMode.WALK]
     * and [TransitMode.UNKNOWN] aren't transit modes and are ignored.
     */
    suspend fun departures(
        id: String,
        numberOfDepartures: Int = 30,
        startTime: Instant? = null,
        timeRange: Duration = 24.hours,
        reliability: Reliability? = null,
        excludedModes: Set<TransitMode>? = null,
    ): SpiderResult<ImmutableList<Departure>> = context(log) {
        spiderCall(tag = "SpiderRouting", message = { "departures failed against $baseUrl (stopId=$id)" }) {
            routing.stopDepartures(id, numberOfDepartures, startTime, timeRange, reliability, excludedModes)
        }
    }

    /**
     * One trip run: [tripId] on the GTFS [serviceDate], formatted "YYYY-MM-DD" (take it from
     * [Departure.serviceDate] or [Leg.serviceDate]). A malformed date returns [SpiderError.BadRequest] without a
     * request. [reliability] is the level [TripStop.typicalDelay] is given at; null leaves it null. The times
     * don't depend on it.
     *
     * [startTime] picks the run of a frequency-based trip (`frequencies.txt`) by its start time, the time it leaves
     * the trip's first stop: a GTFS time `H:MM:SS` or `HH:MM:SS`, hours up to 99, the same value as
     * [LiveVehicle.startTime] and [TripUpdate.startTime]. Null or empty sends nothing and answers the trip's first
     * run on [serviceDate]; a trip without frequencies has one run. A value of another form returns
     * [SpiderError.BadRequest] without a request, and one no run starts at is answered as an unknown trip.
     */
    suspend fun trip(
        tripId: String,
        serviceDate: String,
        reliability: Reliability? = null,
        startTime: String? = null,
    ): SpiderResult<TripDetails> = context(log) {
        spiderCall(tag = "SpiderRouting", message = { "trip failed against $baseUrl (tripId=$tripId)" }) {
            routing.trip(tripId, serviceDate, reliability, startTime)
        }
    }

    /**
     * The delay history at one stop of one trip run, at every [Reliability] level: [tripId] on the GTFS
     * [serviceDate] ("YYYY-MM-DD"), at the stop whose [TripStop.stopPosition] is [stopPosition]. A malformed date
     * returns [SpiderError.BadRequest] without a request.
     *
     * The values are history only, so live realtime never changes them: they are present for a live trip whose
     * [TripStop.typicalDelay] is null. For a trip without live realtime they equal [trip]'s
     * [TripStop.typicalDelay] at that level wherever that is not null. A level with no shift is zero. The result
     * is null when the trip id resolves to no trip, the stop position is not on the trip, or there is no history.
     *
     * [startTime] picks the run of a frequency-based trip as in [trip]; null or empty sends nothing and answers the
     * first run. A value of another form returns [SpiderError.BadRequest] without a request, and one no run starts
     * at gives null.
     */
    suspend fun estimatedDelays(
        tripId: String,
        serviceDate: String,
        stopPosition: Int,
        startTime: String? = null,
    ): SpiderResult<EstimatedDelays?> = context(log) {
        spiderCall(tag = "SpiderRouting", message = { "estimatedDelays failed against $baseUrl (tripId=$tripId)" }) {
            routing.estimatedDelays(tripId, serviceDate, stopPosition, startTime)
        }
    }

    // Pre-warms this surface's connection pool by hitting {baseUrl}/ping. Best-effort, never throws.
    // Exposed on the public API through SpiderClient.warmup(); trip planning (plan/planStream) shares
    // this pool, so warming it here is what makes the first real call ride an already-open connection.
    internal suspend fun warmup(): Duration = routing.warmup()
}

/** Optional configuration for the routing surface. Apply it via `SpiderClient(...) { routing { … } }`. */
class RoutingConfig : SurfaceConfig()

sealed interface Location {
    data class Coordinate(val latitude: Double, val longitude: Double) : Location
    data class Stop(val id: String) : Location
}

/**
 * A stop the itinerary must go through. The journey takes the via locations in the order given, and [PassThrough]
 * and [Visit] may be mixed in one request. How many via locations a request may carry is an environment setting.
 * An unknown stop id comes back as a [RoutingError] with [RoutingErrorCode.LOCATION_NOT_FOUND] and
 * [InputField.VIA].
 */
sealed interface ViaLocation {
    /**
     * The journey passes one of [stopIds] (1 to 10): on board, alighting there, or starting there. A stop where
     * the vehicle doesn't let passengers off isn't passed on board, and walking there to board isn't a pass.
     */
    data class PassThrough(val stopIds: List<String>) : ViaLocation {
        constructor(stopId: String) : this(listOf(stopId))
    }

    /**
     * Passenger must be at [location] (becomes a leg boundary), which must be a [Location.Stop]; a
     * [Location.Coordinate] returns [SpiderError.BadRequest] for `via` without a request. [minimumWaitTime]
     * (0 to 1 hour) forces at least that dwell between arriving and leaving the via stop.
     */
    data class Visit(
        val location: Location,
        val minimumWaitTime: Duration = Duration.ZERO,
    ) : ViaLocation
}

sealed interface RouteTime {
    val time: Instant
    data class DepartAt(override val time: Instant) : RouteTime
    data class ArriveBy(override val time: Instant) : RouteTime
}

data class PlanRequest(
    val origin: Location,
    val destination: Location,
    val time: RouteTime,
    val via: List<ViaLocation> = emptyList(),
    // null = no filter (all modes); a non-empty set restricts routing to those. WALK/UNKNOWN aren't transit
    // modes and drop out. Empty and null both mean "no filter" — never emptySet-as-all.
    val allowedTransitModes: Set<TransitMode>? = null,
    val maxTransfers: Int? = null,
    // Required by the API, which checks it against the environment's search-window limit; sent as given.
    val searchWindow: Duration = 1.hours,
    // true rides only trips the feed marks wheelchair accessible, boards and alights only at stops it marks
    // accessible (no information counts as not accessible), and walks strongly avoiding steps and ways mapped as
    // not wheelchair accessible.
    val wheelchairAccessible: Boolean = false,
    // null plans on the timetable alone.
    val reliability: Reliability? = null,
    // The modes routing must not ride; every other mode stays usable, including one the API adds later. null and
    // empty both mean "no filter"; WALK/UNKNOWN drop out. An alternative to allowedTransitModes: both non-empty is
    // BadRequest for modes.transit without a request.
    val excludedTransitModes: Set<TransitMode>? = null,
)

/**
 * A delay level from the environment's realtime history of a trip at a stop on the service date's day type: the
 * p50, p70 or p90 of its recorded delay. Trip planning ([SpiderRouting.plan]) allows for it at each leg's arrival;
 * boarding keeps the scheduled departure, and a trip with live realtime uses its realtime times.
 * [SpiderRouting.departures] and [SpiderRouting.trip] give their `typicalDelay` at it. Leaving it null means the
 * timetable alone, on every operation.
 */
enum class Reliability {
    /** The typical (median) delay. */
    STANDARD,

    /** The delay 70% of trips stay within. */
    SAFE,

    /** The delay 90% of trips stay within. */
    VERY_SAFE,
}

data class Route(
    val request: PlanRequest,
    val edges: ImmutableList<RouteEdge>,
    val pageInfo: RoutePageInfo,
    val routingErrors: ImmutableList<RoutingError>,
    val searchDateTime: String,
)

data class RouteEdge(
    @Deprecated("Always \"NoCursor\"; page with Route.pageInfo.")
    val cursor: String,
    val itinerary: Itinerary,
)

@Serializable
data class Itinerary(
    val start: String,
    val end: String,
    val durationSeconds: Long,
    val waitingTimeSeconds: Long,
    val numberOfTransfers: Int,
    @Deprecated("Always null.")
    val accessibilityScore: Double? = null,
    @Serializable(with = LegListSerializer::class)
    val legs: ImmutableList<Leg>,
) {
    val stableKey by lazy {
        val legs = legs.joinToString("|") { leg ->
            "${leg.mode}:${leg.tripGtfsId.orEmpty()}:${leg.startScheduled}:${leg.endScheduled}"
        }
        "$start/$end/$legs"
    }
    fun isSameTripAs(other: Itinerary?): Boolean =
        other != null && stableKey == other.stableKey
}

/**
 * One leg of an [Itinerary]. [routeColor] and [routeTextColor] are the route's GTFS colours as raw hex without
 * `#` (e.g. `FF0000`), as the feed gives them. The platform codes and zone ids come from the boarding (`from`)
 * and alighting (`to`) stops; all display fields are null when the feed doesn't provide them.
 *
 * [realtimeState] is the realtime state of the leg's trip; [RealtimeState.SCHEDULED] on a walk.
 *
 * [typicalArrivalDelay] is the delay planning applied to this leg's arrival at the request's [Reliability]; null
 * without one, or when the trip has no history. [interlineWithPreviousLeg] is true when the rider stays on the
 * same vehicle from the previous leg as it carries on as another trip, often under another line number; that
 * change isn't counted in [Itinerary.numberOfTransfers].
 *
 * [fromStopPosition] and [toStopPosition] are the boarding and alighting stops' positions in the leg's trip: the
 * [TripStop] of [SpiderRouting.trip] for [tripGtfsId] and [serviceDate] with the same [TripStop.stopPosition] is
 * that stop. Null on a walk.
 *
 * [pickupType] is how the rider boards at the `from` stop and [dropoffType] how they alight at the `to` stop;
 * [PickupDropoffType.COORDINATE_WITH_DRIVER] is a stop on request. [PickupDropoffType.SCHEDULED] on a walk and
 * where the rider stays on board across an interline.
 *
 * [vehicle] is the vehicle running the leg's trip run, as the realtime trip update names it; null on a walk and
 * until a vehicle is matched to the run.
 */
@Serializable
data class Leg(
    val mode: TransitMode,
    val startScheduled: String,
    val endScheduled: String,
    val startEstimated: String? = null,
    val endEstimated: String? = null,
    val startDelay: Duration? = null,
    val endDelay: Duration? = null,
    val isRealtime: Boolean = false,
    val realtimeState: RealtimeState,
    val serviceDate: String? = null,
    val fromName: String,
    val toName: String,
    val fromGtfsId: String? = null,
    val toGtfsId: String? = null,
    val routeShortName: String?,
    val routeLongName: String?,
    val headsign: String?,
    val distanceMeters: Double,
    val durationSeconds: Long,
    val tripGtfsId: String?,
    val bikesAllowed: BikesAllowed? = null,
    @Deprecated("Always null.")
    val accessibilityScore: Double? = null,
    val fromWheelchair: WheelchairBoarding? = null,
    val toWheelchair: WheelchairBoarding? = null,
    @Serializable(with = LatLonListSerializer::class)
    val geometry: ImmutableList<LatLon> = persistentListOf(),
    val routeGtfsId: String? = null,
    val routeColor: String? = null,
    val routeTextColor: String? = null,
    val fromPlatformCode: String? = null,
    val toPlatformCode: String? = null,
    val fromZoneId: String? = null,
    val toZoneId: String? = null,
    val typicalArrivalDelay: Duration? = null,
    val interlineWithPreviousLeg: Boolean = false,
    val fromStopPosition: Int? = null,
    val toStopPosition: Int? = null,
    val pickupType: PickupDropoffType = PickupDropoffType.SCHEDULED,
    val dropoffType: PickupDropoffType = PickupDropoffType.SCHEDULED,
    val vehicle: TripVehicle? = null,
)

@Serializable
data class LatLon(val lat: Double, val lon: Double)

private object LegListSerializer : ImmutableListSerializer<Leg>(Leg.serializer())
private object LatLonListSerializer : ImmutableListSerializer<LatLon>(LatLon.serializer())

data class RoutePageInfo(
    val startCursor: String?,
    val endCursor: String?,
    val hasNextPage: Boolean,
    val hasPreviousPage: Boolean,
    val searchWindowUsed: String?,
)

/**
 * Why routing declined the plan or kept no transit itinerary in the window: an outcome of the search, not a
 * failed call. [inputField] is the input the [code] refers to, null when it names none; each [RoutingErrorCode]
 * says which.
 */
data class RoutingError(
    val code: RoutingErrorCode,
    val description: String,
    val inputField: InputField?,
)

/**
 * One row of a departures board. [serviceDate] is the GTFS service date the trip runs on ("YYYY-MM-DD"),
 * which for a night departure after midnight is the previous day; pass it with [tripGtfsId] to
 * [SpiderRouting.trip] and [SpiderRealtime.delays].
 *
 * [stopGtfsId] and [platformCode] are the stop the vehicle departs from (on a station's board, the
 * platform). [routeColor] and [routeTextColor] are raw GTFS hex without `#` (e.g. `FF0000`), as the feed
 * gives them. The display fields are null when the feed doesn't provide them.
 *
 * [typicalDelay] is this trip's delay at this stop at the requested [Reliability], from the environment's realtime
 * history; null when no reliability is passed, the trip has live realtime, or there is no history. [stopPosition]
 * is the departure's position in its trip, as the trip's [TripStop.stopPosition].
 *
 * [pickupType] is how a rider boards here, never [PickupDropoffType.NONE]: the board leaves out departures nobody
 * can board. [dropoffType] is how a rider alights here. [PickupDropoffType.COORDINATE_WITH_DRIVER] is a stop on
 * request.
 *
 * [vehicle] is the vehicle running the departure's trip run, as the realtime trip update names it; null until a
 * vehicle is matched to the run.
 */
data class Departure(
    val scheduledTime: Instant,
    val realtimeTime: Instant,
    val isRealtime: Boolean,
    val realtimeState: RealtimeState,
    val headsign: String?,
    val tripGtfsId: String,
    val serviceDate: String,
    val routeShortName: String?,
    val routeLongName: String?,
    val mode: TransitMode,
    val routeGtfsId: String,
    val routeColor: String? = null,
    val routeTextColor: String? = null,
    val stopGtfsId: String,
    val platformCode: String? = null,
    val wheelchairAccessible: WheelchairBoarding? = null,
    val typicalDelay: Duration? = null,
    val stopPosition: Int? = null,
    val pickupType: PickupDropoffType = PickupDropoffType.SCHEDULED,
    val dropoffType: PickupDropoffType = PickupDropoffType.SCHEDULED,
    val vehicle: TripVehicle? = null,
)

/**
 * One trip on [serviceDate] ("YYYY-MM-DD"), the requested GTFS service date its times are anchored to.
 * [routeColor] and [routeTextColor] are raw GTFS hex without `#` (e.g. `FF0000`), as the feed gives them.
 *
 * [vehicle] is the vehicle running the trip run, as the realtime trip update names it; null until a vehicle is
 * matched to the run.
 */
data class TripDetails(
    val gtfsId: String,
    val serviceDate: String,
    val routeShortName: String?,
    val routeLongName: String?,
    val mode: TransitMode,
    val headsign: String?,
    val directionId: String?,
    val bikesAllowed: BikesAllowed? = null,
    val stops: ImmutableList<TripStop>,
    val geometry: ImmutableList<LatLon> = persistentListOf(),
    val routeGtfsId: String,
    val routeColor: String? = null,
    val routeTextColor: String? = null,
    val wheelchairAccessible: WheelchairBoarding? = null,
    val vehicle: TripVehicle? = null,
)

/**
 * [SpiderRouting.estimatedDelays]: the delay history at one stop of a trip run at each [Reliability] level
 * ([Reliability.STANDARD], [Reliability.SAFE], [Reliability.VERY_SAFE]); never negative.
 */
data class EstimatedDelays(
    val standard: Duration,
    val safe: Duration,
    val verySafe: Duration,
)

/**
 * One stop of a [TripDetails]. [typicalDelay] is the trip's delay at this stop at the requested [Reliability],
 * from the environment's realtime history; null when no reliability is passed, the trip has live realtime, or
 * there is no history.
 *
 * [stopPosition] is the stop's position in the trip: increasing along it, not necessarily from 0 or consecutive.
 * A [Leg.fromStopPosition], [Leg.toStopPosition] or [Departure.stopPosition] equal to it names this stop, also on a
 * trip that visits one stop twice. Realtime that adds or removes stops can change it.
 *
 * [geometryIndex] is the index into [TripDetails.geometry] of where the stop sits on the trip's line; null when
 * the trip has no geometry or the stop has no point on it.
 *
 * [pickupType] and [dropoffType] are how a rider boards and alights here; [PickupDropoffType.COORDINATE_WITH_DRIVER]
 * is a stop on request. Null when the stop is canceled: the trip is canceled or realtime skips the stop.
 */
data class TripStop(
    val gtfsId: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val scheduledArrival: Instant,
    val scheduledDeparture: Instant,
    val realtimeArrival: Instant,
    val realtimeDeparture: Instant,
    val isRealtime: Boolean,
    val wheelchairBoarding: WheelchairBoarding? = null,
    val platformCode: String? = null,
    val zoneId: String? = null,
    val typicalDelay: Duration? = null,
    val stopPosition: Int? = null,
    val geometryIndex: Int? = null,
    val pickupType: PickupDropoffType? = null,
    val dropoffType: PickupDropoffType? = null,
)
