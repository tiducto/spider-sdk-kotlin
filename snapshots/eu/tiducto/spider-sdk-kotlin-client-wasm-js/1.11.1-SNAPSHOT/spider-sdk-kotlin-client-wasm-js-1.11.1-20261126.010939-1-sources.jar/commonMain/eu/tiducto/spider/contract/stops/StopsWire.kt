package eu.tiducto.spider.contract.stops

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The stop-search wire contract.
 *
 * **Hand-written, not generated.** Unlike the OTP models under `eu.tiducto.spider.contract.routing`
 * (produced by openapi-generator and wiped/rewritten by `scripts/generate-contract.sh`), these live in
 * their own package so the generator's `rm -rf` on `routing/` never touches them. The real upstream
 * owner of the [StopHit] document shape is the `stops_env_{envId}` index builder (`seed-stops.sh`,
 * another repo) — this file is the SDK-side mirror of that cross-repo contract, pinned by
 * `StopsWireContractTest`.
 *
 * `:client` consumes these internally and maps them to the public domain type `Stop`; they must not
 * appear in `:client`'s public API (`:contract` is an `implementation` dependency; `PublicApiLeakTest`
 * enforces it).
 */

/**
 * POST body for `/stops/v1/search`. [filter] is a stop-search filter expression the client composes;
 * [sort] carries index sort directives (e.g. `_geoPoint(lat, lng):asc` for nearest-first); both are omitted
 * from the wire when null (the encoder drops defaults). [limit] caps the hit count and is always sent.
 */
@Serializable
internal data class StopSearchRequest(
    val q: String,
    val limit: Int,
    val filter: String? = null,
    val sort: List<String>? = null,
)

/**
 * The stop-search envelope. Generic over the hit type (the SDK only ever searches the stops index →
 * `StopSearchResponse<StopHit>`, but the shape is the index-agnostic search response). [query] is the backend's
 * echo of the search term. Extra envelope fields the backend adds (`processingTimeMs`, `estimatedTotalHits`,
 * …) are tolerated by the client's `ignoreUnknownKeys` decoder and intentionally not modeled.
 */
@Serializable
internal data class StopSearchResponse<T>(val hits: List<T>, val query: String)

/**
 * One stop document as indexed. [gtfsId], [name] and the coordinates are always present; the admin-geography
 * levels ([country]…[suburb]) are populated only where the deployment enriched them. [geoDistance] is the
 * distance in metres from a geo sort's point, present only under one. [wheelchairBoarding] is a raw GTFS integer code; [modes] are routing mode names. These field names must match the index builder (`seed-stops.sh`).
 */
@Serializable
internal data class StopHit(
    val gtfsId: String,
    val name: String,
    val code: String? = null,
    val wheelchairBoarding: Int? = null,
    val modes: List<String> = emptyList(),
    val lat: Double,
    val lon: Double,
    val country: String? = null,
    val region: String? = null,
    val district: String? = null,
    val city: String? = null,
    val suburb: String? = null,
    @SerialName("_geoDistance") val geoDistance: Int? = null,
)
