package eu.tiducto.spider.client

internal const val SDK_VERSION: String = "1.10.1-SNAPSHOT"
